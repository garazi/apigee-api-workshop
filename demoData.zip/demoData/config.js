module.exports = {
	// Usergrid path
	UG: "http://localhost:8080/workshop/sandbox"
}