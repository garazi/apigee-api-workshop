module.exports = {
    // Server address
    Server: "http://localhost:10010",
    // Server: "http://YOUR-APIGEE-ORG-test.apigee.net/api-workshop",
    // Usergrid path
    UG: "http://localhost:8080/workshop/sandbox"
    // UG: "http://api.usergrid.com/YOUR-ORG-NAME/sandbox"
};