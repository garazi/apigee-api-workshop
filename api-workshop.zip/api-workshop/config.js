module.exports = {
    // Server address
    Server: "http://localhost:10010",
    // Server: "http://grewis-test.apigee.net/api-workshop",
    // Usergrid path
    UG: "http://localhost:8080/workshop/sandbox"
    // UG: "http://api.usergrid.com/garazi/sandbox"
};