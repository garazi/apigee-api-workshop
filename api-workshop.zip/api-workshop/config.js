module.exports = {
    // Server address
    Server: "http://localhost:10010",
    // Server: "http://YOUR-DEPLOYMENT-URL",
    // Usergrid path
    UG: "http://localhost:8080/workshop/sandbox"
    // UG: "http://api.usergrid.com/YOURORGNAME/sandbox"
};